# Design System Strategy: The Academic Sanctuary

## 1. Overview & Creative North Star
The North Star for this design system is **"The Academic Sanctuary."** 

In the high-pressure world of competitive exams like KEAM, student interfaces are often cluttered, frantic, and anxiety-inducing. This system rejects that chaos. We are building a "Sanctuary"—a space that feels authoritative yet breathing, professional yet deeply encouraging. 

We move beyond the "template" look by utilizing **Editorial Asymmetry**. By pairing high-scale display typography with generous white space and tonal layering, we create an experience that feels like a premium educational journal rather than a rigid database. This approach establishes "Trust" not through borders and boxes, but through sophisticated clarity and intentional depth.

---

## 2. Colors: Tonal Architecture
We use color to define focus, not just decoration. Our palette is built on a foundation of "Trustworthy Blue" with strategic "Success Green" and "Warm Orange" highlights.

### The Color Tokens
*   **Primary (`#0040a1`):** Use for authoritative elements and primary brand touchpoints.
*   **Secondary (`#1b6d24`):** Reserved exclusively for progress, mastery, and "success" states.
*   **Tertiary (`#773200`):** Our Warm Orange. Use sparingly for high-momentum Calls to Action (CTAs) and "Start Test" triggers.
*   **Surfaces:** A range from `surface-container-lowest` (#ffffff) to `surface-dim` (#d9dadb).

### The "No-Line" Rule
**Explicit Instruction:** You are prohibited from using 1px solid borders for sectioning. 
Structure must be defined through background color shifts. For example, a `surface-container-low` (#f3f4f5) sidebar sitting against a `surface` (#f8f9fa) main content area. Boundaries are felt through tonal changes, never "drawn" with lines.

### Glass & Gradient Rule
To provide visual "soul," use **Signature Textures**:
*   **Floating Elements:** Use `surface-container-lowest` at 80% opacity with a `24px` backdrop-blur.
*   **Hero CTAs:** Instead of flat `#0040a1`, use a subtle linear gradient from `primary` (#0040a1) to `primary-container` (#0056d2) at a 135-degree angle. This adds a "premium sheen" that signifies importance.

---

## 3. Typography: Editorial Authority
We utilize a dual-typeface system to balance personality with extreme legibility.

*   **The Display Voice (Manrope):** Used for `display-` and `headline-` scales. Manrope’s geometric yet warm proportions provide a modern, "tech-forward" feel for exam scores and module titles.
*   **The Functional Voice (Inter):** Used for `title-`, `body-`, and `label-` scales. Inter is the industry standard for legibility in dense academic content.

**Scale Strategy:**
*   **The Power of Contrast:** Pair a `display-md` headline (2.75rem) with a `body-md` description (0.875rem). The wide gap in scale creates an "Editorial" look that feels curated and intentional.
*   **Labeling:** Use `label-md` in all-caps with `0.05em` letter-spacing for category tags (e.g., "PHYSICS," "MATHEMATICS") to create a professional, "journal" aesthetic.

---

## 4. Elevation & Depth: Tonal Layering
We do not use heavy shadows to create hierarchy. We use **Physical Stacking**.

*   **The Layering Principle:** 
    *   **Base:** `surface` (#f8f9fa)
    *   **Sections:** `surface-container-low` (#f3f4f5)
    *   **Interactive Cards:** `surface-container-lowest` (#ffffff)
    This creates a soft, natural lift where the most important information (the card) literally looks like it is sitting on top of the section.

*   **Ambient Shadows:** If an element must float (like a FAB or a modal), use a shadow: `box-shadow: 0 12px 32px rgba(25, 28, 29, 0.06);`. The shadow is a tinted version of our `on-surface` color, mimicking natural light.

*   **Ghost Borders:** If accessibility requires a container boundary, use the `outline-variant` token at **15% opacity**. It should be a "whisper" of a line, not a shout.

---

## 5. Components: Intentional Primitives

### Buttons
*   **Primary (The Catalyst):** Uses the Primary-to-Primary-Container gradient. `xl` (1.5rem) roundedness.
*   **Tertiary (The Trigger):** Orange (#773200) reserved for "Submit" or "Start Exam."
*   **Padding:** Use a generous 1:2 ratio (e.g., 16px vertical, 32px horizontal) to ensure buttons feel "sturdy" and premium.

### Progress Bars
*   **Style:** Avoid thin lines. Use a `12px` height with `full` roundedness. 
*   **Logic:** The track should be `surface-variant` (#e1e3e4) and the indicator `secondary` (#1b6d24). Add a subtle inner-glow to the indicator for a "liquid" feel.

### Cards (The "No-Divider" Rule)
Cards are the primary container for exam questions and modules.
*   **Padding:** `24px` internal padding (Spacing Scale `xl`).
*   **Separation:** Do not use lines between list items inside a card. Use `8px` of vertical white space or a subtle `surface-container-high` background on the "active" item.

### Exam Inputs
*   **Focus State:** When a student selects an answer or clicks a text field, the border doesn't just change color—the background shifts to `primary-fixed` (#dae2ff) at 20% opacity to "cradle" the input.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use asymmetrical layouts. Place a large headline on the left and start the body text 1/3rd of the way across the grid to create "breathable" luxury.
*   **Do** use `secondary` (Success Green) for all positive reinforcement. A student's progress should always feel "growing."
*   **Do** use Manrope for large numbers (scores, ranks). Numbers are data; data should be beautiful.

### Don't:
*   **Don't** use 100% black text. Always use `on-surface` (#191c1d) to reduce eye strain during long study sessions.
*   **Don't** use "Standard" 4px rounded corners. Stick to the Roundedness Scale: `lg` (1rem) for cards and `xl` (1.5rem) for buttons to maintain the "Soft Minimalism" vibe.
*   **Don't** use "Pop-up" alerts. Integrate feedback into the UI layers using tonal shifts to avoid breaking the student's "flow state."